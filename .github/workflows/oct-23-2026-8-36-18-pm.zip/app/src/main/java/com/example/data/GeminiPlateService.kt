package com.example.data

import com.example.BuildConfig
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import org.json.JSONArray
import org.json.JSONObject
import java.util.concurrent.TimeUnit

data class GeminiAnalysisResult(
    val vehicleType: VehicleType?,
    val plateNumber: String,
    val isSuccess: Boolean,
    val aiNote: String? = null
)

object GeminiPlateService {

    private const val BASE_URL = "https://generativelanguage.googleapis.com/v1beta/models/gemini-3.5-flash:generateContent"

    private val okHttpClient = OkHttpClient.Builder()
        .connectTimeout(60, TimeUnit.SECONDS)
        .readTimeout(60, TimeUnit.SECONDS)
        .writeTimeout(60, TimeUnit.SECONDS)
        .build()

    fun isApiKeyConfigured(): Boolean {
        return try {
            val key = BuildConfig.GEMINI_API_KEY
            key.isNotBlank() && key != "MY_GEMINI_API_KEY"
        } catch (e: Exception) {
            false
        }
    }

    /**
     * Sends the spoken speech input to Gemini Live AI to extract:
     * 1. Vehicle Type (ونيت, تاكسي, ميكروباص, نقل, ملاكي)
     * 2. License Plate with 4 digits and 3 letters (if 3 digits spoken, adds '0' at the start).
     */
    suspend fun analyzeSpokenPlate(spokenText: String): GeminiAnalysisResult = withContext(Dispatchers.IO) {
        val apiKey = try {
            BuildConfig.GEMINI_API_KEY
        } catch (e: Exception) {
            ""
        }

        if (apiKey.isBlank() || apiKey == "MY_GEMINI_API_KEY") {
            // Fallback to local parsing
            val (type, plate) = VehicleType.extractFromSpeech(spokenText)
            val formatted = PlateNormalizer.formatDisplay(plate)
            return@withContext GeminiAnalysisResult(
                vehicleType = type,
                plateNumber = formatted,
                isSuccess = true,
                aiNote = "تحليل محلي (قاعدة 4 أرقام مع إضافة 0)"
            )
        }

        try {
            val systemPrompt = """
                أنت محلل ذكاء اصطناعي صوتي Live AI خبير في لوحات المركبات العربية والمصرية.
                المستخدم نطق بالصوت النص التالي: "$spokenText"
                
                القواعد الصارمة:
                1. استخرج نوع المركبة من أحد الأنواع فقط: (ونيت, تاكسي, ميكروباص, نقل, ملاكي, أخرى).
                   - كلمات تدل على ونيت: ونيت، دبابة، بيك اب، نص نقل.
                   - كلمات تدل على تاكسي: تاكسي، أجرة، ليموزين.
                   - كلمات تدل على ميكروباص: ميكروباص، باص، سرفيس، مشروع.
                   - كلمات تدل على نقل: نقل، شاحنة، تريلا، جامبو.
                   - كلمات تدل على ملاكي: ملاكي، خصوصي، سيارة خاصة.
                2. استخرج أرقام اللوحة: اللوحة يجب أن تكون 4 أرقام.
                   - هام جداً: إذا نطق المستخدم 3 أرقام فقط (مثال: '123' أو 'واحد اتنين تلاتة')، أضف رقم 0 في البداية لتصبح 4 أرقام (مثال: '0123').
                3. استخرج حروف اللوحة: 3 حروف عربية مفصولة بمسافة (مثال: 'أ ب ج').
                4. صيغة اللوحة النهائية: [الأرقام الـ 4] [الحروف الـ 3] (مثال: '0123 أ ب ج').
                
                يجب الرد فقط بكائن JSON التالي بدون أي نص إضافي:
                {
                  "type": "ونيت",
                  "plate": "0123 أ ب ج",
                  "digitsCount": 4,
                  "addedLeadingZero": true,
                  "note": "تم إضافة 0 في البداية لتكتمل 4 أرقام"
                }
            """.trimIndent()

            val requestJson = JSONObject().apply {
                val contentsArray = JSONArray().apply {
                    val contentObj = JSONObject().apply {
                        val partsArray = JSONArray().apply {
                            put(JSONObject().apply { put("text", systemPrompt) })
                        }
                        put("parts", partsArray)
                    }
                    put(contentObj)
                }
                put("contents", contentsArray)

                val generationConfig = JSONObject().apply {
                    put("responseMimeType", "application/json")
                    put("temperature", 0.1)
                }
                put("generationConfig", generationConfig)
            }

            val requestBody = requestJson.toString().toRequestBody("application/json".toMediaType())
            val request = Request.Builder()
                .url("$BASE_URL?key=$apiKey")
                .post(requestBody)
                .build()

            val response = okHttpClient.newCall(request).execute()
            if (!response.isSuccessful) {
                // Fallback to local
                val (type, plate) = VehicleType.extractFromSpeech(spokenText)
                val formatted = PlateNormalizer.formatDisplay(plate)
                return@withContext GeminiAnalysisResult(
                    vehicleType = type,
                    plateNumber = formatted,
                    isSuccess = true,
                    aiNote = "تحليل محلي (تمت إضافة 0 للأرقام)"
                )
            }

            val responseString = response.body?.string() ?: ""
            val jsonResponse = JSONObject(responseString)
            val candidates = jsonResponse.optJSONArray("candidates")
            val firstCandidate = candidates?.optJSONObject(0)
            val content = firstCandidate?.optJSONObject("content")
            val parts = content?.optJSONArray("parts")
            val text = parts?.optJSONObject(0)?.optString("text") ?: ""

            if (text.isNotBlank()) {
                val parsedAi = JSONObject(text.trim())
                val typeStr = parsedAi.optString("type")
                val plateStr = parsedAi.optString("plate")
                val note = parsedAi.optString("note")

                val detectedType = VehicleType.fromArabicName(typeStr)
                val finalPlate = if (plateStr.isNotBlank()) PlateNormalizer.formatDisplay(plateStr) else PlateNormalizer.formatDisplay(spokenText)

                GeminiAnalysisResult(
                    vehicleType = detectedType,
                    plateNumber = finalPlate,
                    isSuccess = true,
                    aiNote = if (note.isNotBlank()) "Gemini Live AI: $note" else "تم التحليل بواسطة Gemini Live AI"
                )
            } else {
                val (type, plate) = VehicleType.extractFromSpeech(spokenText)
                val formatted = PlateNormalizer.formatDisplay(plate)
                GeminiAnalysisResult(
                    vehicleType = type,
                    plateNumber = formatted,
                    isSuccess = true,
                    aiNote = "تحليل محلي (قاعدة 4 أرقام)"
                )
            }
        } catch (e: Exception) {
            e.printStackTrace()
            val (type, plate) = VehicleType.extractFromSpeech(spokenText)
            val formatted = PlateNormalizer.formatDisplay(plate)
            GeminiAnalysisResult(
                vehicleType = type,
                plateNumber = formatted,
                isSuccess = true,
                aiNote = "تحليل محلي (احتياطي)"
            )
        }
    }
}
