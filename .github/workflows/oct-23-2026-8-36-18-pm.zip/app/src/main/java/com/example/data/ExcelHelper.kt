package com.example.data

import android.content.Context
import android.content.Intent
import android.net.Uri
import androidx.core.content.FileProvider
import java.io.BufferedReader
import java.io.File
import java.io.FileOutputStream
import java.io.InputStreamReader
import java.io.OutputStreamWriter
import java.nio.charset.StandardCharsets
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

object ExcelHelper {

    private val dateFormat = SimpleDateFormat("yyyy/MM/dd", Locale("ar"))
    private val timeFormat = SimpleDateFormat("HH:mm:ss", Locale("ar"))
    private val fileTimestampFormat = SimpleDateFormat("yyyyMMdd_HHmmss", Locale.US)

    /**
     * Exports recorded plates to an Excel-compatible CSV file with UTF-8 BOM.
     * Excel automatically interprets the UTF-8 BOM (\uFEFF) and displays Arabic perfectly.
     */
    fun exportRecordedPlatesToExcel(
        context: Context,
        plates: List<RecordedPlate>
    ): File {
        val exportDir = File(context.cacheDir, "exports").apply { mkdirs() }
        val filename = "سجل_اللوحات_${fileTimestampFormat.format(Date())}.csv"
        val file = File(exportDir, filename)

        FileOutputStream(file).use { fos ->
            OutputStreamWriter(fos, StandardCharsets.UTF_8).use { writer ->
                // Write UTF-8 BOM for Microsoft Excel compatibility with Arabic
                writer.write("\uFEFF")

                // Write Header
                val header = listOf(
                    "م",
                    "رقم اللوحة",
                    "نوع المركبة",
                    "تاريخ الرصد",
                    "وقت الرصد",
                    "خط العرض (Latitude)",
                    "خط الطول (Longitude)",
                    "العنوان / الموقع",
                    "حالة المطابقة",
                    "اللوحة المطابقة",
                    "سبب المطابقة والملاحظات",
                    "النص الصوتي الملتقط",
                    "رابط خرائط جوجل"
                )
                writer.write(header.joinToString(",") { escapeCsv(it) })
                writer.write("\r\n")

                // Write Rows
                plates.forEachIndexed { index, plate ->
                    val dateStr = dateFormat.format(Date(plate.timestamp))
                    val timeStr = timeFormat.format(Date(plate.timestamp))
                    val type = VehicleType.fromId(plate.vehicleType).arabicName
                    val matchStatus = if (plate.isMatched) "مطابقة لقائمة المراقبة" else "غير مسجلة بالمراقبة"
                    val mapsLink = if (plate.latitude != null && plate.longitude != null) {
                        "https://maps.google.com/?q=${plate.latitude},${plate.longitude}"
                    } else {
                        "غير متوفر"
                    }

                    val row = listOf(
                        (index + 1).toString(),
                        plate.plateNumber,
                        type,
                        dateStr,
                        timeStr,
                        plate.latitude?.toString() ?: "",
                        plate.longitude?.toString() ?: "",
                        plate.address ?: "",
                        matchStatus,
                        plate.matchedTargetPlate ?: "",
                        listOfNotNull(plate.matchedReason, plate.notes.ifBlank { null }).joinToString(" - "),
                        plate.rawSpeechText ?: "",
                        mapsLink
                    )
                    writer.write(row.joinToString(",") { escapeCsv(it) })
                    writer.write("\r\n")
                }
            }
        }
        return file
    }

    /**
     * Creates a share intent for an exported Excel CSV file
     */
    fun getShareIntent(context: Context, file: File): Intent {
        val uri: Uri = FileProvider.getUriForFile(
            context,
            "${context.packageName}.fileprovider",
            file
        )
        return Intent(Intent.ACTION_SEND).apply {
            type = "text/csv"
            putExtra(Intent.EXTRA_STREAM, uri)
            putExtra(Intent.EXTRA_SUBJECT, "تصدير سجل اللوحات المرصودة")
            putExtra(Intent.EXTRA_TEXT, "مرفق ملف إكسل يحتوي على سجل اللوحات المرصودة مع الموقع ونوع المركبة.")
            addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
        }
    }

    /**
     * Generates a sample template CSV that user can open in Excel, populate with target plates, and import back.
     */
    fun createSampleWatchlistTemplate(context: Context): File {
        val exportDir = File(context.cacheDir, "exports").apply { mkdirs() }
        val file = File(exportDir, "نموذج_قائمة_لوحات_المراقبة.csv")

        FileOutputStream(file).use { fos ->
            OutputStreamWriter(fos, StandardCharsets.UTF_8).use { writer ->
                writer.write("\uFEFF")
                // Header
                writer.write(listOf("رقم اللوحة", "نوع المركبة", "سبب المراقبة", "ملاحظات إضافية").joinToString(",") { escapeCsv(it) })
                writer.write("\r\n")

                // Sample rows representing the requested vehicle types:
                val samples = listOf(
                    listOf("123 أ ب ج", "ونيت", "مطلوبة للتفتيش", "دبابة بيضاء موديل حديث"),
                    listOf("456 د ه و", "تاكسي", "مخالفة سرعة وحظر تجول", "تاكسي أصفر العاصمة"),
                    listOf("789 س ص ع", "ميكروباص", "انتهاء ترخيص السير", "ميكروباص أبيض خط الدائري"),
                    listOf("321 ط ظ ع", "نقل", "فحص حمولة زائدة", "شاحنة نقل مقطورة زرقاء"),
                    listOf("555 ك ل م", "ملاكي", "لوحة مسروقة", "سيارة سيدان سوداء")
                )

                samples.forEach { row ->
                    writer.write(row.joinToString(",") { escapeCsv(it) })
                    writer.write("\r\n")
                }
            }
        }
        return file
    }

    /**
     * Parses an imported CSV file from an Android content URI.
     * Supports both comma (,) and semicolon (;) separators commonly produced by regional Excel versions.
     */
    fun parseWatchlistFromUri(context: Context, uri: Uri, sourceFileName: String): List<WatchlistPlate> {
        val results = mutableListOf<WatchlistPlate>()
        val inputStream = context.contentResolver.openInputStream(uri) ?: return emptyList()

        BufferedReader(InputStreamReader(inputStream, StandardCharsets.UTF_8)).use { reader ->
            var lineIndex = 0
            var delimiter: Char? = null

            var line = reader.readLine()
            // Strip BOM if present
            if (line != null && line.startsWith("\uFEFF")) {
                line = line.substring(1)
            }

            var plateCol = 0
            var typeCol = 1
            var reasonCol = 2
            var notesCol = 3

            while (line != null) {
                val trimmed = line.trim()
                if (trimmed.isNotEmpty()) {
                    // Determine delimiter on first valid line
                    if (delimiter == null) {
                        delimiter = when {
                            trimmed.count { it == ';' } > trimmed.count { it == ',' } -> ';'
                            trimmed.count { it == '\t' } > trimmed.count { it == ',' } -> '\t'
                            else -> ','
                        }
                    }

                    val tokens = parseCsvLine(trimmed, delimiter)
                    if (tokens.isNotEmpty()) {
                        if (lineIndex == 0) {
                            // Check if this is a header line
                            val isHeader = tokens.any { token ->
                                val lower = token.lowercase()
                                lower.contains("لوحة") || lower.contains("plate") ||
                                        lower.contains("نوع") || lower.contains("type") ||
                                        lower.contains("سبب") || lower.contains("reason")
                            }

                            if (isHeader) {
                                tokens.forEachIndexed { idx, token ->
                                    val t = token.lowercase()
                                    if (t.contains("لوحة") || t.contains("plate") || t.contains("رقم")) plateCol = idx
                                    else if (t.contains("نوع") || t.contains("type")) typeCol = idx
                                    else if (t.contains("سبب") || t.contains("reason")) reasonCol = idx
                                    else if (t.contains("ملاحظ") || t.contains("note") || t.contains("مالك")) notesCol = idx
                                }
                                lineIndex++
                                line = reader.readLine()
                                continue
                            }
                        }

                        // Extract fields safely
                        val rawPlate = tokens.getOrNull(plateCol)?.trim().orEmpty()
                        if (rawPlate.isNotBlank()) {
                            val rawType = tokens.getOrNull(typeCol)?.trim().orEmpty()
                            val reason = tokens.getOrNull(reasonCol)?.trim().orEmpty().ifBlank { "لوحة مراقبة مستوردة" }
                            val notes = tokens.getOrNull(notesCol)?.trim().orEmpty()

                            // Normalize vehicle type
                            val detectedType = VehicleType.fromArabicName(rawType)
                            val typeId = if (rawType.isNotBlank()) detectedType.id else ""

                            results.add(
                                WatchlistPlate(
                                    plateNumber = PlateNormalizer.formatDisplay(rawPlate),
                                    normalizedPlate = PlateNormalizer.normalize(rawPlate),
                                    vehicleType = typeId,
                                    reason = reason,
                                    notes = notes,
                                    sourceFile = sourceFileName
                                )
                            )
                        }
                    }
                    lineIndex++
                }
                line = reader.readLine()
            }
        }
        return results
    }

    private fun escapeCsv(value: String): String {
        return if (value.contains(",") || value.contains(";") || value.contains("\n") || value.contains("\"")) {
            "\"" + value.replace("\"", "\"\"") + "\""
        } else {
            value
        }
    }

    private fun parseCsvLine(line: String, delimiter: Char): List<String> {
        val result = mutableListOf<String>()
        val current = StringBuilder()
        var inQuotes = false
        var i = 0

        while (i < line.length) {
            val c = line[i]
            if (c == '\"') {
                if (inQuotes && i + 1 < line.length && line[i + 1] == '\"') {
                    current.append('\"')
                    i++
                } else {
                    inQuotes = !inQuotes
                }
            } else if (c == delimiter && !inQuotes) {
                result.add(current.toString().trim())
                current.clear()
            } else {
                current.append(c)
            }
            i++
        }
        result.add(current.toString().trim())
        return result
    }
}
