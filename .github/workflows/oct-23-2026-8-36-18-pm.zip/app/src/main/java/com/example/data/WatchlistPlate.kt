package com.example.data

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "watchlist_plates")
data class WatchlistPlate(
    @PrimaryKey(autoGenerate = true)
    val id: Long = 0,
    val plateNumber: String,
    val normalizedPlate: String,
    val vehicleType: String = "",
    val reason: String = "لوحة مطلوبة",
    val notes: String = "",
    val sourceFile: String = "إدخال يدوي",
    val dateAdded: Long = System.currentTimeMillis()
)
