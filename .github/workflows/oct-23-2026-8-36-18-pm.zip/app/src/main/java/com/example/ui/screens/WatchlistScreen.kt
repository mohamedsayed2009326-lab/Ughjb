package com.example.ui.screens

import android.content.Intent
import android.net.Uri
import android.widget.Toast
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Clear
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.DeleteOutline
import androidx.compose.material.icons.filled.DeleteSweep
import androidx.compose.material.icons.filled.Description
import androidx.compose.material.icons.filled.Download
import androidx.compose.material.icons.filled.FileDownload
import androidx.compose.material.icons.filled.FileUpload
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.filled.Security
import androidx.compose.material.icons.filled.TableChart
import androidx.compose.material.icons.filled.UploadFile
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.ElevatedButton
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.ExcelHelper
import com.example.data.VehicleType
import com.example.data.WatchlistPlate
import com.example.ui.PlateViewModel
import com.example.ui.components.LicensePlateBadge
import com.example.ui.components.VehicleTypeBadge
import com.example.ui.components.VehicleTypeSelector
import com.example.ui.theme.AlertRed

@Composable
fun WatchlistScreen(
    viewModel: PlateViewModel,
    modifier: Modifier = Modifier
) {
    val context = LocalContext.current
    val watchlist by viewModel.filteredWatchlistPlates.collectAsState()
    val totalCount by viewModel.watchlistCount.collectAsState()
    val searchQuery by viewModel.watchlistSearchQuery.collectAsState()

    var showAddDialog by remember { mutableStateOf(false) }
    var showClearDialog by remember { mutableStateOf(false) }

    // Excel / CSV File Picker Launcher
    val filePickerLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.GetContent()
    ) { uri: Uri? ->
        if (uri != null) {
            val fileName = uri.lastPathSegment ?: "ملف إكسل"
            viewModel.importWatchlistFromUri(uri, fileName)
        }
    }

    Column(
        modifier = modifier
            .fillMaxSize()
            .padding(horizontal = 16.dp)
    ) {
        Spacer(modifier = Modifier.height(8.dp))

        // Top Section: Title & Stats
        Row(
            modifier = Modifier.fillMaxWidth(),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            Column {
                Text(
                    text = "قائمة المراقبة والمطابقة",
                    fontSize = 18.sp,
                    fontWeight = FontWeight.Bold,
                    color = MaterialTheme.colorScheme.onSurface
                )
                Text(
                    text = "اللوحات المستوردة من إكسل: $totalCount",
                    fontSize = 12.sp,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }

            Row(horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                // Add manual target plate
                IconButton(
                    onClick = { showAddDialog = true },
                    modifier = Modifier.testTag("add_manual_target_btn")
                ) {
                    Icon(
                        imageVector = Icons.Default.Add,
                        contentDescription = "إضافة لوحة",
                        tint = MaterialTheme.colorScheme.primary
                    )
                }

                if (totalCount > 0) {
                    IconButton(
                        onClick = { showClearDialog = true },
                        modifier = Modifier.testTag("clear_watchlist_btn")
                    ) {
                        Icon(
                            imageVector = Icons.Default.DeleteSweep,
                            contentDescription = "مسح الكل",
                            tint = AlertRed.copy(alpha = 0.8f)
                        )
                    }
                }
            }
        }

        Spacer(modifier = Modifier.height(10.dp))

        // Excel Operations Action Bar
        Card(
            shape = RoundedCornerShape(16.dp),
            colors = CardDefaults.cardColors(
                containerColor = MaterialTheme.colorScheme.primaryContainer.copy(alpha = 0.4f)
            ),
            modifier = Modifier.fillMaxWidth()
        ) {
            Column(modifier = Modifier.padding(12.dp)) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    // Import Excel/CSV Button
                    ElevatedButton(
                        onClick = {
                            filePickerLauncher.launch("*/*")
                        },
                        colors = ButtonDefaults.elevatedButtonColors(
                            containerColor = Color(0xFF107C41), // Excel Green
                            contentColor = Color.White
                        ),
                        shape = RoundedCornerShape(10.dp),
                        modifier = Modifier
                            .weight(1f)
                            .testTag("import_excel_file_btn")
                    ) {
                        Icon(
                            imageVector = Icons.Default.FileUpload,
                            contentDescription = null,
                            modifier = Modifier.size(16.dp)
                        )
                        Spacer(modifier = Modifier.width(4.dp))
                        Text("استيراد إكسل", fontSize = 12.sp, fontWeight = FontWeight.Bold)
                    }

                    // Share/Download Template Button
                    OutlinedButton(
                        onClick = {
                            val templateFile = viewModel.createSampleTemplate()
                            val shareIntent = ExcelHelper.getShareIntent(context, templateFile)
                            context.startActivity(Intent.createChooser(shareIntent, "مشاركة نموذج إكسل"))
                            Toast.makeText(context, "تم تجهيز نموذج الإكسل", Toast.LENGTH_SHORT).show()
                        },
                        shape = RoundedCornerShape(10.dp),
                        modifier = Modifier
                            .weight(1f)
                            .testTag("download_template_btn")
                    ) {
                        Icon(
                            imageVector = Icons.Default.FileDownload,
                            contentDescription = null,
                            modifier = Modifier.size(16.dp)
                        )
                        Spacer(modifier = Modifier.width(4.dp))
                        Text("نموذج إكسل", fontSize = 12.sp)
                    }
                }

                Spacer(modifier = Modifier.height(6.dp))

                // Quick load sample test data button
                TextButton(
                    onClick = { viewModel.loadSampleWatchlist() },
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("load_sample_data_btn")
                ) {
                    Icon(
                        imageVector = Icons.Default.TableChart,
                        contentDescription = null,
                        modifier = Modifier.size(15.dp)
                    )
                    Spacer(modifier = Modifier.width(6.dp))
                    Text(
                        text = "تحميل عينة لوحات تجريبية لاختبار التطابق (ونيت، تاكسي، ميكروباص...)",
                        fontSize = 12.sp,
                        color = MaterialTheme.colorScheme.primary
                    )
                }
            }
        }

        Spacer(modifier = Modifier.height(10.dp))

        // Search Input
        OutlinedTextField(
            value = searchQuery,
            onValueChange = { viewModel.setWatchlistSearchQuery(it) },
            placeholder = { Text("ابحث في قائمة المراقبة...") },
            leadingIcon = {
                Icon(
                    imageVector = Icons.Default.Search,
                    contentDescription = null,
                    tint = MaterialTheme.colorScheme.onSurfaceVariant
                )
            },
            trailingIcon = {
                if (searchQuery.isNotBlank()) {
                    IconButton(onClick = { viewModel.setWatchlistSearchQuery("") }) {
                        Icon(
                            imageVector = Icons.Default.Close,
                            contentDescription = "مسح"
                        )
                    }
                }
            },
            singleLine = true,
            shape = RoundedCornerShape(12.dp),
            modifier = Modifier
                .fillMaxWidth()
                .testTag("watchlist_search_input")
        )

        Spacer(modifier = Modifier.height(10.dp))

        // Watchlist Platelist
        if (watchlist.isEmpty()) {
            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(vertical = 32.dp),
                contentAlignment = Alignment.Center
            ) {
                Surface(
                    color = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f),
                    shape = RoundedCornerShape(16.dp),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column(
                        modifier = Modifier.padding(24.dp),
                        horizontalAlignment = Alignment.CenterHorizontally
                    ) {
                        Icon(
                            imageVector = Icons.Default.Security,
                            contentDescription = null,
                            tint = MaterialTheme.colorScheme.primary.copy(alpha = 0.6f),
                            modifier = Modifier.size(48.dp)
                        )
                        Spacer(modifier = Modifier.height(8.dp))
                        Text(
                            text = "قائمة المراقبة فارغة حالياً",
                            fontSize = 15.sp,
                            fontWeight = FontWeight.Bold,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                        Text(
                            text = "قم باستيراد ملف إكسل يحتوي على اللوحات المستهدفة أو اضغط على 'تحميل عينة لوحات تجريبية' للتجربة فوراً.",
                            fontSize = 12.sp,
                            color = MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.8f),
                            modifier = Modifier.padding(top = 4.dp),
                            lineHeight = 18.sp
                        )
                    }
                }
            }
        } else {
            LazyColumn(
                modifier = Modifier.fillMaxSize(),
                verticalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                items(watchlist, key = { it.id }) { item ->
                    WatchlistCardItem(
                        item = item,
                        onDelete = { viewModel.deleteWatchlistPlate(it) }
                    )
                }
                item {
                    Spacer(modifier = Modifier.height(16.dp))
                }
            }
        }
    }

    // Add Plate Dialog
    if (showAddDialog) {
        AddWatchlistPlateDialog(
            onDismiss = { showAddDialog = false },
            onConfirm = { plate, type, reason, notes ->
                viewModel.addManualWatchlistPlate(plate, type, reason, notes)
                showAddDialog = false
            }
        )
    }

    // Clear All Dialog
    if (showClearDialog) {
        AlertDialog(
            onDismissRequest = { showClearDialog = false },
            title = { Text("إفراغ قائمة المراقبة") },
            text = { Text("هل تريد حذف كافة اللوحات المراقبة من قاعدة البيانات؟") },
            confirmButton = {
                Button(
                    onClick = {
                        viewModel.clearWatchlist()
                        showClearDialog = false
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = AlertRed)
                ) {
                    Text("إفراغ القائمة")
                }
            },
            dismissButton = {
                TextButton(onClick = { showClearDialog = false }) {
                    Text("إلغاء")
                }
            }
        )
    }
}

@Composable
fun WatchlistCardItem(
    item: WatchlistPlate,
    onDelete: (WatchlistPlate) -> Unit,
    modifier: Modifier = Modifier
) {
    Card(
        shape = RoundedCornerShape(14.dp),
        colors = CardDefaults.cardColors(
            containerColor = MaterialTheme.colorScheme.surface
        ),
        border = BorderStroke(1.dp, MaterialTheme.colorScheme.outline.copy(alpha = 0.25f)),
        modifier = modifier.fillMaxWidth()
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(12.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            Column(modifier = Modifier.weight(1f)) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    LicensePlateBadge(plateNumber = item.plateNumber)
                    if (item.vehicleType.isNotBlank()) {
                        VehicleTypeBadge(vehicleTypeId = item.vehicleType)
                    }
                }

                Spacer(modifier = Modifier.height(6.dp))

                Text(
                    text = "السبب: ${item.reason}",
                    fontSize = 13.sp,
                    fontWeight = FontWeight.SemiBold,
                    color = AlertRed
                )

                if (item.notes.isNotBlank()) {
                    Text(
                        text = item.notes,
                        fontSize = 11.sp,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }

                Text(
                    text = "المصدر: ${item.sourceFile}",
                    fontSize = 10.sp,
                    color = MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.6f)
                )
            }

            IconButton(
                onClick = { onDelete(item) },
                modifier = Modifier.testTag("delete_watchlist_item_${item.id}")
            ) {
                Icon(
                    imageVector = Icons.Default.DeleteOutline,
                    contentDescription = "حذف",
                    tint = AlertRed.copy(alpha = 0.8f)
                )
            }
        }
    }
}

@Composable
fun AddWatchlistPlateDialog(
    onDismiss: () -> Unit,
    onConfirm: (plate: String, type: String, reason: String, notes: String) -> Unit
) {
    var plate by remember { mutableStateOf("") }
    var selectedType by remember { mutableStateOf(VehicleType.PICKUP) }
    var reason by remember { mutableStateOf("") }
    var notes by remember { mutableStateOf("") }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("إضافة لوحة لقائمة المراقبة") },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                OutlinedTextField(
                    value = plate,
                    onValueChange = { plate = it },
                    label = { Text("رقم اللوحة") },
                    placeholder = { Text("مثال: 123 أ ب ج") },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth().testTag("add_dialog_plate_input")
                )

                Text("نوع المركبة:", fontSize = 12.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                VehicleTypeSelector(
                    selectedType = selectedType,
                    onSelectType = { selectedType = it }
                )

                OutlinedTextField(
                    value = reason,
                    onValueChange = { reason = it },
                    label = { Text("سبب المراقبة / البلاغ") },
                    placeholder = { Text("مثال: مطلوبة للتفتيش، مسروقة...") },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth().testTag("add_dialog_reason_input")
                )

                OutlinedTextField(
                    value = notes,
                    onValueChange = { notes = it },
                    label = { Text("ملاحظات إضافية أو تفاصيل") },
                    placeholder = { Text("لون المركبة، معلومات المالك...") },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth().testTag("add_dialog_notes_input")
                )
            }
        },
        confirmButton = {
            Button(
                onClick = {
                    if (plate.isNotBlank()) {
                        onConfirm(plate, selectedType.id, reason, notes)
                    }
                },
                modifier = Modifier.testTag("confirm_add_dialog_btn")
            ) {
                Text("إضافة")
            }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) {
                Text("إلغاء")
            }
        }
    )
}
