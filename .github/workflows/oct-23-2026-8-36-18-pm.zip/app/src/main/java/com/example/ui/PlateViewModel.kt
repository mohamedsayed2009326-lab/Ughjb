package com.example.ui

import android.app.Application
import android.content.Context
import android.net.Uri
import android.os.Build
import android.os.VibrationEffect
import android.os.Vibrator
import android.os.VibratorManager
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.data.AppDatabase
import com.example.data.ExcelHelper
import com.example.data.LocationService
import com.example.data.AudioAlertManager
import com.example.data.GeminiPlateService
import com.example.data.PlateNormalizer
import com.example.data.RecordedPlate
import com.example.data.VehicleType
import com.example.data.WatchlistPlate
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.File

data class LastSpeechInfo(
    val rawSpeech: String,
    val detectedType: VehicleType?,
    val plateNumber: String,
    val isMatched: Boolean,
    val address: String?
)

class PlateViewModel(application: Application) : AndroidViewModel(application) {

    private val db = AppDatabase.getDatabase(application)
    private val dao = db.plateDao()
    private val locationService = LocationService(application)
    private val audioAlertManager = AudioAlertManager(application)

    // Current Navigation Tab (0 = Scan/Voice, 1 = History/Records, 2 = Watchlist/Excel)
    private val _currentTab = MutableStateFlow(0)
    val currentTab: StateFlow<Int> = _currentTab.asStateFlow()

    // Selected vehicle type for current recording
    private val _selectedVehicleType = MutableStateFlow(VehicleType.PICKUP)
    val selectedVehicleType: StateFlow<VehicleType> = _selectedVehicleType.asStateFlow()

    // Manual input text
    private val _manualPlateInput = MutableStateFlow("")
    val manualPlateInput: StateFlow<String> = _manualPlateInput.asStateFlow()

    // Location fetching status
    private val _isGettingLocation = MutableStateFlow(false)
    val isGettingLocation: StateFlow<Boolean> = _isGettingLocation.asStateFlow()

    // Speech listening status
    private val _isListening = MutableStateFlow(false)
    val isListening: StateFlow<Boolean> = _isListening.asStateFlow()

    // Alert for instant match
    private val _matchedAlertPlate = MutableStateFlow<RecordedPlate?>(null)
    val matchedAlertPlate: StateFlow<RecordedPlate?> = _matchedAlertPlate.asStateFlow()

    // Last recognized speech feedback
    private val _lastSpeechInfo = MutableStateFlow<LastSpeechInfo?>(null)
    val lastSpeechInfo: StateFlow<LastSpeechInfo?> = _lastSpeechInfo.asStateFlow()

    // Snackbar / Toast message
    private val _userMessage = MutableStateFlow<String?>(null)
    val userMessage: StateFlow<String?> = _userMessage.asStateFlow()

    // Filters & Search
    private val _historySearchQuery = MutableStateFlow("")
    val historySearchQuery: StateFlow<String> = _historySearchQuery.asStateFlow()

    private val _historyTypeFilter = MutableStateFlow<VehicleType?>(null)
    val historyTypeFilter: StateFlow<VehicleType?> = _historyTypeFilter.asStateFlow()

    private val _historyMatchedOnlyFilter = MutableStateFlow(false)
    val historyMatchedOnlyFilter: StateFlow<Boolean> = _historyMatchedOnlyFilter.asStateFlow()

    private val _watchlistSearchQuery = MutableStateFlow("")
    val watchlistSearchQuery: StateFlow<String> = _watchlistSearchQuery.asStateFlow()

    // Raw streams from DB
    private val allRecordedPlates = dao.getAllRecordedPlates()
    val recentPlates = dao.getRecentRecordedPlates(limit = 15)
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    private val allWatchlistPlates = dao.getAllWatchlistPlates()

    // Filtered Recorded Plates
    val filteredRecordedPlates: StateFlow<List<RecordedPlate>> = combine(
        allRecordedPlates,
        _historySearchQuery,
        _historyTypeFilter,
        _historyMatchedOnlyFilter
    ) { plates, query, typeFilter, matchedOnly ->
        plates.filter { plate ->
            val matchesQuery = query.isBlank() ||
                    plate.plateNumber.contains(query, ignoreCase = true) ||
                    PlateNormalizer.normalize(plate.plateNumber).contains(PlateNormalizer.normalize(query)) ||
                    plate.address?.contains(query, ignoreCase = true) == true ||
                    plate.matchedReason?.contains(query, ignoreCase = true) == true

            val matchesType = typeFilter == null || plate.vehicleType == typeFilter.id
            val matchesOnlyMatched = !matchedOnly || plate.isMatched

            matchesQuery && matchesType && matchesOnlyMatched
        }
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    // Filtered Watchlist Plates
    val filteredWatchlistPlates: StateFlow<List<WatchlistPlate>> = combine(
        allWatchlistPlates,
        _watchlistSearchQuery
    ) { watchlist, query ->
        watchlist.filter { item ->
            query.isBlank() ||
                    item.plateNumber.contains(query, ignoreCase = true) ||
                    PlateNormalizer.normalize(item.plateNumber).contains(PlateNormalizer.normalize(query)) ||
                    item.reason.contains(query, ignoreCase = true) ||
                    item.notes.contains(query, ignoreCase = true)
        }
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    // Counters
    val recordedCount: StateFlow<Int> = dao.getRecordedCount()
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), 0)

    val matchedCount: StateFlow<Int> = dao.getMatchedCount()
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), 0)

    val watchlistCount: StateFlow<Int> = dao.getWatchlistCount()
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), 0)

    fun selectTab(tabIndex: Int) {
        _currentTab.value = tabIndex
    }

    fun selectVehicleType(type: VehicleType) {
        _selectedVehicleType.value = type
    }

    fun setManualPlateInput(text: String) {
        _manualPlateInput.value = text
    }

    fun setHistorySearchQuery(query: String) {
        _historySearchQuery.value = query
    }

    fun setHistoryTypeFilter(type: VehicleType?) {
        _historyTypeFilter.value = type
    }

    fun toggleMatchedOnlyFilter() {
        _historyMatchedOnlyFilter.value = !_historyMatchedOnlyFilter.value
    }

    fun setWatchlistSearchQuery(query: String) {
        _watchlistSearchQuery.value = query
    }

    fun clearUserMessage() {
        _userMessage.value = null
    }

    fun dismissMatchAlert() {
        _matchedAlertPlate.value = null
    }

    fun setListeningState(listening: Boolean) {
        _isListening.value = listening
    }

    /**
     * Process speech recognition output:
     * Extracts vehicle type if spoken (ونيت, تاكسي, ميكروباص, نقل...),
     * normalizes the plate, gets current GPS location, checks watchlist, and saves.
     */
    fun processVoiceInput(spokenText: String) {
        if (spokenText.isBlank()) {
            _userMessage.value = "لم يتم التقاط أي صوت، يرجى المحاولة مرة أخرى."
            return
        }

        viewModelScope.launch {
            _isGettingLocation.value = true

            // 1. Analyze with Gemini Live AI (falls back to local rules)
            val aiResult = withContext(Dispatchers.IO) {
                GeminiPlateService.analyzeSpokenPlate(spokenText)
            }
            val finalType = aiResult.vehicleType ?: _selectedVehicleType.value
            _selectedVehicleType.value = finalType

            val formattedPlate = PlateNormalizer.formatDisplay(aiResult.plateNumber)
            val normalized = PlateNormalizer.normalize(aiResult.plateNumber)

            // 2. Fetch current GPS location
            val locationData = locationService.getCurrentLocation()
            _isGettingLocation.value = false

            // 3. Match against Watchlist
            val watchlist = withContext(Dispatchers.IO) { dao.getWatchlistSync() }
            val matchedTarget = watchlist.firstOrNull { target ->
                PlateNormalizer.isMatch(target.normalizedPlate, normalized)
            }

            val recorded = RecordedPlate(
                plateNumber = formattedPlate,
                normalizedPlate = normalized,
                vehicleType = finalType.id,
                timestamp = System.currentTimeMillis(),
                latitude = locationData?.latitude,
                longitude = locationData?.longitude,
                address = locationData?.address ?: if (locationData != null) "إحداثيات مسجلة" else "الموقع غير متوفر",
                isMatched = matchedTarget != null,
                matchedTargetPlate = matchedTarget?.plateNumber,
                matchedReason = matchedTarget?.reason,
                rawSpeechText = spokenText,
                notes = matchedTarget?.notes ?: ""
            )

            val id = withContext(Dispatchers.IO) { dao.insertRecordedPlate(recorded) }
            val savedRecord = recorded.copy(id = id)

            _lastSpeechInfo.value = LastSpeechInfo(
                rawSpeech = spokenText,
                detectedType = aiResult.vehicleType,
                plateNumber = formattedPlate,
                isMatched = matchedTarget != null,
                address = locationData?.address
            )

            if (matchedTarget != null) {
                // Play buzzer and speak out loud: "طلعت! اللوحة مطابقة!"
                audioAlertManager.playMatchAlertVoiceAndTone()
                _matchedAlertPlate.value = savedRecord
                triggerMatchHaptics()
                _userMessage.value = "تنبيه: طلعت! اللوحة مسجلة في قائمة المراقبة (${matchedTarget.reason})!"
            } else {
                _userMessage.value = "تم رصد ${finalType.arabicName} لوحة $formattedPlate بنجاح مع الموقع."
            }
        }
    }

    /**
     * Submit manually entered plate
     */
    fun submitManualPlate() {
        val input = _manualPlateInput.value.trim()
        if (input.isBlank()) {
            _userMessage.value = "يرجى كتابة رقم اللوحة أولاً"
            return
        }

        viewModelScope.launch {
            _isGettingLocation.value = true
            val formattedPlate = PlateNormalizer.formatDisplay(input)
            val normalized = PlateNormalizer.normalize(input)
            val currentType = _selectedVehicleType.value

            val locationData = locationService.getCurrentLocation()
            _isGettingLocation.value = false

            val watchlist = withContext(Dispatchers.IO) { dao.getWatchlistSync() }
            val matchedTarget = watchlist.firstOrNull { target ->
                PlateNormalizer.isMatch(target.normalizedPlate, normalized)
            }

            val recorded = RecordedPlate(
                plateNumber = formattedPlate,
                normalizedPlate = normalized,
                vehicleType = currentType.id,
                timestamp = System.currentTimeMillis(),
                latitude = locationData?.latitude,
                longitude = locationData?.longitude,
                address = locationData?.address ?: if (locationData != null) "إحداثيات مسجلة" else "الموقع غير متوفر",
                isMatched = matchedTarget != null,
                matchedTargetPlate = matchedTarget?.plateNumber,
                matchedReason = matchedTarget?.reason,
                rawSpeechText = null,
                notes = matchedTarget?.notes ?: ""
            )

            val id = withContext(Dispatchers.IO) { dao.insertRecordedPlate(recorded) }
            _manualPlateInput.value = ""

            val savedRecord = recorded.copy(id = id)
            if (matchedTarget != null) {
                audioAlertManager.playMatchAlertVoiceAndTone()
                _matchedAlertPlate.value = savedRecord
                triggerMatchHaptics()
                _userMessage.value = "تنبيه: طلعت! اللوحة تطابق قائمة المراقبة (${matchedTarget.reason})!"
            } else {
                _userMessage.value = "تم حفظ لوحة $formattedPlate بنجاح."
            }
        }
    }

    fun deleteRecordedPlate(plate: RecordedPlate) {
        viewModelScope.launch(Dispatchers.IO) {
            dao.deleteRecordedPlate(plate)
        }
    }

    fun clearAllRecordedPlates() {
        viewModelScope.launch(Dispatchers.IO) {
            dao.deleteAllRecordedPlates()
            _userMessage.value = "تم مسح جميع سجلات اللوحات."
        }
    }

    fun deleteWatchlistPlate(item: WatchlistPlate) {
        viewModelScope.launch(Dispatchers.IO) {
            dao.deleteWatchlistPlate(item)
        }
    }

    fun clearWatchlist() {
        viewModelScope.launch(Dispatchers.IO) {
            dao.clearWatchlist()
            _userMessage.value = "تم إفراغ قائمة المراقبة."
        }
    }

    fun addManualWatchlistPlate(plateNumber: String, vehicleType: String, reason: String, notes: String) {
        if (plateNumber.isBlank()) return
        viewModelScope.launch(Dispatchers.IO) {
            dao.insertWatchlistPlate(
                WatchlistPlate(
                    plateNumber = PlateNormalizer.formatDisplay(plateNumber),
                    normalizedPlate = PlateNormalizer.normalize(plateNumber),
                    vehicleType = vehicleType,
                    reason = reason.ifBlank { "لوحة مراقبة" },
                    notes = notes,
                    sourceFile = "إدخال يدوي"
                )
            )
            _userMessage.value = "تمت إضافة اللوحة لقائمة المراقبة بنجاح."
        }
    }

    fun importWatchlistFromUri(uri: Uri, fileName: String) {
        viewModelScope.launch {
            try {
                val plates = withContext(Dispatchers.IO) {
                    ExcelHelper.parseWatchlistFromUri(getApplication(), uri, fileName)
                }
                if (plates.isEmpty()) {
                    _userMessage.value = "لم يتم العثور على لوحات صالحة داخل الملف المحدد."
                } else {
                    withContext(Dispatchers.IO) {
                        dao.insertWatchlistPlates(plates)
                    }
                    _userMessage.value = "تم استيراد ${plates.size} لوحة بنجاح من ملف $fileName."
                }
            } catch (e: Exception) {
                e.printStackTrace()
                _userMessage.value = "حدث خطأ أثناء قراءة ملف الإكسل: ${e.localizedMessage}"
            }
        }
    }

    /**
     * Seeds the watchlist with helpful starter plates for testing the matching feature immediately
     */
    fun loadSampleWatchlist() {
        viewModelScope.launch(Dispatchers.IO) {
            val samples = listOf(
                WatchlistPlate(
                    plateNumber = "123 أ ب ج",
                    normalizedPlate = PlateNormalizer.normalize("123 أ ب ج"),
                    vehicleType = VehicleType.PICKUP.id,
                    reason = "مطلوبة للتفتيش - اشتباه حمولة",
                    notes = "ونيت أبيض موديل 2023",
                    sourceFile = "عينة تجريبية"
                ),
                WatchlistPlate(
                    plateNumber = "456 د ه و",
                    normalizedPlate = PlateNormalizer.normalize("456 د ه و"),
                    vehicleType = VehicleType.TAXI.id,
                    reason = "حظر سير ومخالفات متراكمة",
                    notes = "تاكسي أصفر العاصمة",
                    sourceFile = "عينة تجريبية"
                ),
                WatchlistPlate(
                    plateNumber = "789 س ص ع",
                    normalizedPlate = PlateNormalizer.normalize("789 س ص ع"),
                    vehicleType = VehicleType.MICROBUS.id,
                    reason = "انتهاء رخصة القيادة والخط",
                    notes = "ميكروباص خط الدائري",
                    sourceFile = "عينة تجريبية"
                ),
                WatchlistPlate(
                    plateNumber = "321 ط ظ ع",
                    normalizedPlate = PlateNormalizer.normalize("321 ط ظ ع"),
                    vehicleType = VehicleType.TRUCK.id,
                    reason = "تجاوز حمولة موازين الطرق",
                    notes = "شاحنة نقل زرقاء",
                    sourceFile = "عينة تجريبية"
                )
            )
            dao.insertWatchlistPlates(samples)
            _userMessage.value = "تم تحميل ${samples.size} لوحات تجريبية مطابقة لقائمة المراقبة."
        }
    }

    suspend fun exportPlatesToExcel(): File? = withContext(Dispatchers.IO) {
        val plates = filteredRecordedPlates.value
        if (plates.isEmpty()) return@withContext null
        ExcelHelper.exportRecordedPlatesToExcel(getApplication(), plates)
    }

    fun createSampleTemplate(): File {
        return ExcelHelper.createSampleWatchlistTemplate(getApplication())
    }

    private fun triggerMatchHaptics() {
        try {
            val context = getApplication<Application>()
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
                val vibratorManager = context.getSystemService(Context.VIBRATOR_MANAGER_SERVICE) as? VibratorManager
                vibratorManager?.defaultVibrator?.vibrate(
                    VibrationEffect.createWaveform(longArrayOf(0, 250, 100, 250, 100, 400), -1)
                )
            } else {
                @Suppress("DEPRECATION")
                val vibrator = context.getSystemService(Context.VIBRATOR_SERVICE) as? Vibrator
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                    vibrator?.vibrate(
                        VibrationEffect.createWaveform(longArrayOf(0, 250, 100, 250, 100, 400), -1)
                    )
                } else {
                    @Suppress("DEPRECATION")
                    vibrator?.vibrate(longArrayOf(0, 250, 100, 250), -1)
                }
            }
        } catch (e: Exception) {
            // Ignore if vibrator not accessible
        }
    }

    override fun onCleared() {
        super.onCleared()
        audioAlertManager.shutdown()
    }
}
