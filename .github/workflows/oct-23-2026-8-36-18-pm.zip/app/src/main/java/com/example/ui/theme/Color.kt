package com.example.ui.theme

import androidx.compose.ui.graphics.Color

// Light Scheme Colors
val PrimaryBlue = Color(0xFF0F4C81)
val OnPrimaryBlue = Color(0xFFFFFFFF)
val PrimaryContainer = Color(0xFFD6E4FF)
val OnPrimaryContainer = Color(0xFF001B3E)

val SecondaryTeal = Color(0xFF028090)
val OnSecondaryTeal = Color(0xFFFFFFFF)
val SecondaryContainer = Color(0xFFCEFAF8)

val BackgroundLight = Color(0xFFF8FAFC)
val SurfaceLight = Color(0xFFFFFFFF)
val SurfaceVariantLight = Color(0xFFEEF2F6)
val OutlineLight = Color(0xFFCBD5E1)

// Dark Scheme Colors
val PrimaryBlueDark = Color(0xFF86B8F8)
val OnPrimaryBlueDark = Color(0xFF003062)
val PrimaryContainerDark = Color(0xFF004688)

val SecondaryTealDark = Color(0xFF4DD8D2)
val BackgroundDark = Color(0xFF0F172A)
val SurfaceDark = Color(0xFF1E293B)
val SurfaceVariantDark = Color(0xFF334155)
val OutlineDark = Color(0xFF475569)

// Accent Colors
val AlertRed = Color(0xFFDC2626)
val AlertRedContainer = Color(0xFFFEE2E2)
val OnAlertRedContainer = Color(0xFF991B1B)

val SuccessGreen = Color(0xFF16A34A)
val SuccessGreenContainer = Color(0xFFDCFCE7)

val WarningAmber = Color(0xFFD97706)
val WarningAmberContainer = Color(0xFFFEF3C7)
